import os, sys
sys.path.append(os.path.dirname(__file__))

from common import *
from dataset.reader import *
from net.layer.box.process import *

ALL_TEST_IMAGE_ID =[
'f0d0ab13ff53adc3c4d57e95a5f83d80b06f2cbc0bf002b52cf7b496612e0ce4',
 'dab46d798d29aff2e99c23f47ed3064f5cafb1644629b015c95a2dd2ee593bb4',
 '4be73d68f433869188fe5e7f09c7f681ed51003da6aa5d19ce368726d8e271ee',
 '31f1fbe85b8899258ea5bcf5f93f7ac8238660c386aeab40649c715bd2e38a0a',
 '912a679e4b9b1d1a75170254fd675b8c24b664d80ad7ea7e460241a23535a406',
 'ade080c6618cbbb0a25680cf847f312b5e19b22bfe1cafec0436987ebe5b1e7e',
 '1cdbfee1951356e7b0a215073828695fe1ead5f8b1add119b6645d2fdc8d844e',
 '519dc0d672d1c295fc69b629af8721ccb1a1f136d1976685a68487e62547ffe0',
 'df40099c6306ca1f47fcc8a62e2fa39486d4e223177afdc51b2ad189691802d8',
 'e17b7aedd251a016c01ef9158e6e4aa940d9f1b35942d86028dc1222192a9258',
 '697a05c6fe4a07c601d46da80885645ad574ea19b47ee795ccff216c9f1f1808',
 'd616d323a9eeb9da1b66f8d5df671d63c092c9919cb2c0b223e29c63257c944d',
 '7f4cbe0b36b5d09466476a7d4e01f4f976c67872d549f4ff47b3e1e3a2b403af',
 'fe9adb627a6f45747c5a8223b671774791ededf9364f6544be487c540107fa4f',
 '505bc0a3928d8aef5ce441c5a611fdd32e1e8eccdc15cc3a52b88030acb50f81',
 '0e132f71c8b4875c3c2dd7a22997468a3e842b46aa9bd47cf7b0e8b7d63f0925',
 '4f949bd8d914bbfa06f40d6a0e2b5b75c38bf53dbcbafc48c97f105bee4f8fac',
 '0114f484a16c152baa2d82fdd43740880a762c93f436c8988ac461c5c9dbe7d5',
 'a4816cc1fb76cb3c5e481186833fc0ae9cf426a1406a2607e974e65e9cddba4f',
 '8922a6ac8fd0258ec27738ca101867169b20d90a60fc84f93df77acd5bf7c80b',
 '336d3e4105766f8ad328a7ee9571e743f376f8cbcf6a969ca7e353fe3235c523',
 'ca20076870e8fb604e61802605a9ac45419c82dd3e23404c56c4869f9502a5ef',
 '699f2992cd71e2e28cf45f81347ff22e76b37541ce88087742884cd0e9aadc68',
 '53df5150ee56253fe5bc91a9230d377bb21f1300f443ba45a758bcb01a15c0e4',
 '78a981bd27ba0c65a9169548665a17bda9f49050d0d3893a6567d1eb92cd003d',
 '191b2b2205f2f5cc9da04702c5d422bc249faf8bca1107af792da63cccfba829',
 '648c8ffa496e1716017906d0bf135debfc93386ae86aa3d4adbda9a505985fd9',
 '1879f4f4f05e2bada0ffeb46c128b8df7a79b14c84f38c3e216a69653495153b',
 '7bdb668e6127b7eafc837a883f0648002bd063c736f55a4f673e787250a3fb04',
 '43a71aeb641faa18742cb826772a8566c6c947d7050f9ab15459de6cc2b3b6af',
 '295682d9eb5acb5c1976a460c085734bfaf38482b0a3f02591c2bfdcd4128549',
 '550450e4bff4036fd671decdc5d42fec23578198d6a2fd79179c4368b9d6da18',
 'eea70a7948d25a9a791dbcb39228af4ea4049fe5ebdee9c04884be8cca3da835',
 '1ef68e93964c2d9230100c1347c328f6385a7bc027879dc3d4c055e6fe80cb3c',
 'ab298b962a63e4be9582513aaa84a5e270adba5fd2b16a50e59540524f63c3b8',
 'fac507fa4d1649e8b24c195d990f1fc3ca3633d917839e1751a9d412a14ab5e3',
 '8b59819fbc92eefe45b1db95c0cc3a467ddcfc755684c7f2ba2f6ccb9ad740ab',
 '9ab2d381f90b485a68b82bc07f94397a0373e3215ad20935a958738e55f3cfc2',
 '0ed3555a4bd48046d3b63d8baf03a5aa97e523aa483aaa07459e7afa39fb96c6',
 'a984e7fb886aa02e29d112766d3ce26a4f78eac540ce7bbdbd42af2761928f6d',
 '1962d0c5faf3e85cda80e0578e0cb7aca50826d781620e5c1c4cc586bc69f81a',
 '432f367a4c5b5674de2e2977744d10289a064e5704b21af6607b4975be47c580',
 'd6eb7ce7723e2f6dc13b90b41a29ded27dbd815bad633fdf582447c686018896',
 'bdc789019cee8ddfae20d5f769299993b4b330b2d38d1218646cf89e77fbbd4d',
 '1747f62148a919c8feb6d607faeebdf504b5e2ad42b6b1710b1189c37ebcdb2c',
 '4727d94c6a57ed484270fdd8bbc6e3d5f2f15d5476794a4e37a40f2309a091e2',
 '52b267e20519174e3ce1e1994b5d677804b16bc670aa5f6ffb6344a0fdf63fde',
 '0a849e0eb15faa8a6d7329c3dd66aabe9a294cccb52ed30a90c8ca99092ae732',
 'd8d4bf68a76e4e4c5f21de7ac613451f7115a04db686151e78b8ec0b6a22022b',
 '38f5cfb55fc8b048e82a5c895b25fefae7a70c71ab9990c535d1030637bf6a1f',
 '5cee644e5ffbef1ba021c7f389b33bafd3b1841f04d3edd7922d5084c2c4e0c7',
 '51c70bb8a299943b27f8b354571272692d8f2705036a1a9562156c76da5f025b',
 '0999dab07b11bc85fb8464fc36c947fbd8b5d6ec49817361cb780659ca805eac'
]


def check_valid(proposal, width, height):

    num_proposal = len(proposal)

    keep=[]
    for n in range(num_proposal):
        b,x0,y0,x1,y1,score,label,aux = proposal[n]
        w = x1 - x0
        h = y1 - y0

        valid = 1
        if (w*h <10) or \
           (x0<w/4          and h/w>3.5) or \
           (x1>width-1-w/4  and h/w>3.5) or \
           (y0<h/4          and w/h>3.5) or \
           (y1>height-1-h/4 and w/h>3.5) or \
           0: valid=0

        if valid:
            keep.append(n)

    return keep


#remove border
def make_tight_proposal(proposal, border, width, height):
    proposal = proposal.copy()
    x0 = proposal[:,1]
    y0 = proposal[:,2]
    x1 = proposal[:,3]
    y1 = proposal[:,4]
    w = x1 - x0
    h = y1 - y0
    x = (x1 + x0)/2
    y = (y1 + y0)/2

    aa =  w - h
    bb = (w + h)/(2*border+1)
    ww = np.clip((aa + bb)/2, 0, np.inf)
    hh = np.clip((bb - aa)/2, 0, np.inf)

    is_boundy_x0 = x0 < w/4
    is_boundy_x1 = x1 > width-1 -w/4
    is_boundy_y0 = y0 < h/4
    is_boundy_y1 = y1 > height-1-h/4

    proposal[:, 1] = is_boundy_x0*x0 + (1-is_boundy_x0)*(x - ww/2)
    proposal[:, 2] = is_boundy_y0*y0 + (1-is_boundy_y0)*(y - hh/2)
    proposal[:, 3] = is_boundy_x1*x1 + (1-is_boundy_x1)*(x + ww/2)
    proposal[:, 4] = is_boundy_y1*y1 + (1-is_boundy_y1)*(y + hh/2)
    return proposal

#ensemble =======================================================

class Cluster(object):
    def __init__(self):
        super(Cluster, self).__init__()
        self.members=[]
        self.center =[]

    def add_item(self, box, score, instance):
        if self.center ==[]:
            self.members = [{
                'box': box, 'score': score, 'instance': instance
            },]
            self.center  = {
                'box': box, 'score': score, 'union':(instance>0.5), 'inter':(instance>0.5),
            }
        else:
            self.members.append({
                'box': box, 'score': score, 'instance': instance
            })
            center_box   = self.center['box'].copy()
            center_score = self.center['score']
            center_union = self.center['union'].copy()
            center_inter = self.center['inter'].copy()

            self.center['box'] = [
                min(box[0],center_box[0]),
                min(box[1],center_box[1]),
                max(box[2],center_box[2]),
                max(box[3],center_box[3]),
            ]
            self.center['score'] = max(score,center_score)
            self.center['union'] = center_union | (instance>0.5)
            self.center['inter'] = center_inter & (instance>0.5)

    def distance(self, box, score, instance):
        center_box   = self.center['box']
        center_union = self.center['union']
        center_inter = self.center['inter']

        x0 = int(max(box[0],center_box[0]))
        y0 = int(max(box[1],center_box[1]))
        x1 = int(min(box[2],center_box[2]))
        y1 = int(min(box[3],center_box[3]))

        w = max(0,x1-x0)
        h = max(0,y1-y0)
        box_intersection = w*h
        if box_intersection<0.01: return 0

        x0 = int(min(box[0],center_box[0]))
        y0 = int(min(box[1],center_box[1]))
        x1 = int(max(box[2],center_box[2]))
        y1 = int(max(box[3],center_box[3]))

        i0 = center_union[y0:y1,x0:x1]  #center_inter[y0:y1,x0:x1]
        i1 = instance[y0:y1,x0:x1]>0.5

        intersection = np.logical_and(i0, i1).sum()
        area = np.logical_or(i0, i1).sum()
        overlap = intersection/(area + 1e-12)

        return overlap




def do_clustering( boxes, scores, instances, threshold=0.5):

    clusters = []
    num_arguments   = len(instances)
    for n in range(0,num_arguments):
        box   = boxes[n]
        score = scores[n]
        instance = instances[n]

        num = len(instance)
        for m in range(num):
            b, s, i = box[m],score[m],instance[m]

            is_group = 0
            for c in clusters:
                iou = c.distance(b, s, i)

                if iou>threshold:
                    c.add_item(b, s, i)
                    is_group=1

            if is_group == 0:
                c = Cluster()
                c.add_item(b, s, i)
                clusters.append(c)

    return clusters

#
# def mask_to_more(mask):
#     H,W      = mask.shape[:2]
#     box      = []
#     score    = []
#     instance = []
#
#     for i in range(mask.max()):
#         m = (mask==(i+1))
#
#         #filter by size, boundary, etc ....
#         if 1:
#
#             #box
#             y,x = np.where(m)
#             y0 = y.min()
#             y1 = y.max()
#             x0 = x.min()
#             x1 = x.max()
#             b = [x0,y0,x1,y1]
#
#             #score
#             s = 1
#
#             # add --------------------
#             box.append(b)
#             score.append(s)
#             instance.append(m)
#
#             # image_show('m',m*255)
#             # cv2.waitKey(0)
#
#     box      = np.array(box,np.float32)
#     score    = np.array(score,np.float32)
#     instance = np.array(instance,np.float32)
#
#     if len(box)==0:
#         box      = np.zeros((0,4),np.float32)
#         score    = np.zeros((0,1),np.float32)
#         instance = np.zeros((0,H,W),np.float32)
#
#     return box, score, instance
#
#
# def run_ensemble():
#
#     out_dir = \
#         '/root/share/project/kaggle/science2018/results/__ensemble__/yyy'
#         #'/root/share/project/kaggle/science2018/results/__old_3__/ensemble_example/ouput'
#         #'/root/share/project/kaggle/science2018/results/__ensemble__/xxx'
#
#     ensemble_dirs = [
#         #different predictors, test augments, etc ...
#
#         # '/root/share/project/kaggle/science2018/results/mask-se-resnext50-rcnn_2crop-mega-01/evaluate_test/test1_ids_gray2_53-00011000_model',
#         # '/root/share/project/kaggle/science2018/results/mask-se-resnext50-rcnn_2crop-mega-01/evaluate_test/test1_ids_gray2_53-00017000_model',
#         # '/root/share/project/kaggle/science2018/results/__submit__/LB-0.523/npys-0.570'
#
#         # '/root/share/project/kaggle/science2018/results/mask-se-resnext50-rcnn_2crop-mega-01/predict/xxx',
#         # '/root/share/project/kaggle/science2018/results/mask-se-resnext50-rcnn_2crop-mega-01/predict/xxx_horizontal_flip',
#         # '/root/share/project/kaggle/science2018/results/mask-se-resnext50-rcnn_2crop-mega-01/predict/xxx_vertical_flip',
#         # '/root/share/project/kaggle/science2018/results/mask-se-resnext50-rcnn_2crop-mega-01/predict/xxx_scale_1.2',
#         # '/root/share/project/kaggle/science2018/results/mask-se-resnext50-rcnn_2crop-mega-01/predict/xxx_scale_0.8',
#
#         # '/root/share/project/kaggle/science2018/results/__old_3__/ensemble_example/input/original',
#         # '/root/share/project/kaggle/science2018/results/__old_3__/ensemble_example/input/horizontal_flip',
#         # '/root/share/project/kaggle/science2018/results/__old_3__/ensemble_example/input/vertical_flip',
#         # '/root/share/project/kaggle/science2018/results/__old_3__/ensemble_example/input/scale_1.2',
#         # '/root/share/project/kaggle/science2018/results/__old_3__/ensemble_example/input/scale_0.8',
#
#        '/root/share/project/kaggle/science2018/results/mask-se-resnext50-rcnn_2crop-mega-01/predict/yyy_normal',
#        '/root/share/project/kaggle/science2018/results/mask-se-resnext50-rcnn_2crop-mega-01/predict/yyy_normal_unsharp',
#        '/root/share/project/kaggle/science2018/results/mask-se-resnext50-rcnn_2crop-mega-01/predict/yyy_normal_clahe',
#        '/root/share/project/kaggle/science2018/results/mask-se-resnext50-rcnn_2crop-mega-01/predict/yyy_normal_horizontal_flip',
#        #'/root/share/project/kaggle/science2018/results/mask-se-resnext50-rcnn_2crop-mega-01/predict/yyy_vertical_flip',
#        '/root/share/project/kaggle/science2018/results/mask-se-resnext50-rcnn_2crop-mega-01/predict/yyy_normal_scale_1.5',
#        '/root/share/project/kaggle/science2018/results/mask-se-resnext50-rcnn_2crop-mega-01/predict/yyy_normal_scale_0.5',
#
#     ]
#
#     ## setup  --------------------------
#     os.makedirs(out_dir +'/average_semantic_mask', exist_ok=True)
#     os.makedirs(out_dir +'/cluster_union_mask', exist_ok=True)
#     os.makedirs(out_dir +'/cluster_inter_mask', exist_ok=True)
#     os.makedirs(out_dir +'/ensemble_mask', exist_ok=True)
#     os.makedirs(out_dir +'/ensemble_mask_overlays', exist_ok=True)
#
#
#     names = glob.glob(ensemble_dirs[0] + '/overlays/*/')
#     names = [n.split('/')[-2]for n in names]
#     sorted(names)
#
#     num_ensemble = len(ensemble_dirs)
#     for name in names:
#         #name='1cdbfee1951356e7b0a215073828695fe1ead5f8b1add119b6645d2fdc8d844e'
#         print(name)
#         boxes=[]
#         scores=[]
#         instances=[]
#
#         average_semantic_mask = None
#         for dir in ensemble_dirs:
#             # npy_file = dir +'/%s.npy'%name
#             # mask = np.load(npy_file)
#             png_file   = dir +'/overlays/%s/%s.mask.png'%(name,name)
#             mask_image = cv2.imread(png_file,cv2.IMREAD_COLOR)
#             mask       = image_to_mask(mask_image)
#
#             if average_semantic_mask is None:
#                 average_semantic_mask = (mask>0).astype(np.float32)
#             else:
#                 average_semantic_mask = average_semantic_mask + (mask>0).astype(np.float32)
#
#             # color_overlay = mask_to_color_overlay(mask)
#             # image_show('color_overlay',color_overlay)
#             # image_show('average_semantic_mask',average_semantic_mask*255)
#             # cv2.waitKey(0)
#
#             box, score, instance = mask_to_more(mask)
#             boxes.append(box)
#             scores.append(score)
#             instances.append(instance)
#
#
#         average_semantic_mask = average_semantic_mask/num_ensemble
#         clusters = do_clustering( boxes, scores, instances, threshold=0.3)
#         H,W      = average_semantic_mask.shape[:2]
#
#
#         # <todo> do your ensemble  here! =======================================
#         ensemble_mask = np.zeros((H,W), np.int32)
#         for i,c in enumerate(clusters):
#             num_members = len(c.members)
#             average = np.zeros((H,W), np.float32)  #e.g. use average
#             for n in range(num_members):
#                 average = average + c.members[n]['instance']
#             average = average/num_members
#
#             ensemble_mask[average>0.5] = i+1
#
#         #do some post processing here ---
#         # e.g. fill holes
#         #      remove small fragment
#         #      remove boundary
#         # <todo> do your ensemble  here! =======================================
#
#
#
#
#         # show clustering/ensmeble results
#         cluster_inter_mask = np.zeros((H,W), np.int32)
#         cluster_union_mask = np.zeros((H,W), np.int32)
#         for i,c in enumerate(clusters):
#             cluster_inter_mask[c.center['inter']]=i+1
#             cluster_union_mask[c.center['union']]=i+1
#
#             # image_show('all',all/num_members*255)
#             # cv2.waitKey(0)
#             # pass
#
#         color_overlay0 = mask_to_color_overlay(cluster_inter_mask)
#         color_overlay1 = mask_to_color_overlay(cluster_union_mask)
#         color_overlay2 = mask_to_color_overlay(ensemble_mask)
#         ##-------------------------
#         average_semantic_mask = (average_semantic_mask*255).astype(np.uint8)
#         average_semantic_mask = cv2.cvtColor(average_semantic_mask,cv2.COLOR_GRAY2BGR)
#
#         cv2.imwrite(out_dir +'/average_semantic_mask/%s.png'%(name),average_semantic_mask)
#         cv2.imwrite(out_dir +'/cluster_inter_mask/%s.mask.png'%(name),color_overlay0)
#         cv2.imwrite(out_dir +'/cluster_union_mask/%s.mask.png'%(name),color_overlay1)
#         cv2.imwrite(out_dir +'/ensemble_mask/%s.mask.png'%(name),color_overlay2)
#
#         image_show('average_semantic_mask',average_semantic_mask)
#         image_show('cluster_inter_mask',color_overlay0)
#         image_show('cluster_union_mask',color_overlay1)
#         #image_show('ensemble_mask',color_overlay2)
#
#         if 1:
#             folder = 'stage1_test'
#             image = cv2.imread(DATA_DIR + '/image/%s/images/%s.png'%(folder,name), cv2.IMREAD_COLOR)
#
#             mask = ensemble_mask
#             norm_image      = adjust_gamma(image,2.5)
#             color_overlay   = mask_to_color_overlay(mask)
#             color1_overlay  = mask_to_contour_overlay(mask, color_overlay)
#             contour_overlay = mask_to_contour_overlay(mask, norm_image, [0,255,0])
#             all = np.hstack((image, contour_overlay, color1_overlay)).astype(np.uint8)
#             image_show('ensemble_mask',all)
#
#             #psd
#             cv2.imwrite(out_dir +'/ensemble_mask_overlays/%s.png'%(name),all)
#             os.makedirs(out_dir +'/ensemble_mask_overlays/%s'%(name), exist_ok=True)
#             cv2.imwrite(out_dir +'/ensemble_mask_overlays/%s/%s.png'%(name,name),image)
#             cv2.imwrite(out_dir +'/ensemble_mask_overlays/%s/%s.mask.png'%(name,name),color_overlay)
#             cv2.imwrite(out_dir +'/ensemble_mask_overlays/%s/%s.contour.png'%(name,name),contour_overlay)
#
#
#
#         cv2.waitKey(1)
#         # pass


def run_ensemble_box():
    out_dir = \
        '/home/yl/kaggle_mine/2018_Data_Science_Bowl/Hen/20180306/results/mask-se-resnext50-rcnn_2crop-mega-05c/predict/xx_ensemble'

    ensemble_dirs = [
        'xx_normal',
        'xx_flip_transpose_1',
        'xx_flip_transpose_2',
        'xx_flip_transpose_3',
        'xx_flip_transpose_4',
        'xx_flip_transpose_5',
        'xx_flip_transpose_6',
        'xx_flip_transpose_7',
        'xx_scale_0.8',
        'xx_scale_1.2',
    ]
    ensemble_dirs = [
        '/home/yl/kaggle_mine/2018_Data_Science_Bowl/Hen/20180306/results/mask-se-resnext50-rcnn_2crop-mega-05c/predict/%s'%e for e in ensemble_dirs
    ]

    ##submit
    submit_dir = \
        '/home/yl/kaggle_mine/2018_Data_Science_Bowl/Hen/20180306/results/mask-se-resnext50-rcnn_2crop-mega-05c/predict/xx_ensemble/proposal'

    # image_dir   = '/root/share/project/kaggle/science2018/data/image/stage1_test/images'
    #
    # submit_dir  = \
    #     '/root/share/project/kaggle/science2018/results/mask-rcnn-50-gray500-02/submit'

    npy_dir = submit_dir + '/npys'
    csv_file = submit_dir + '/submission-gray53-49000_2.csv'
    ## start -----------------------------
    all_num=0
    cvs_ImageId = [];
    cvs_EncodedPixels = [];


    #setup ---------------------------------------
    os.makedirs(out_dir +'/proposal/overlays', exist_ok=True)
    os.makedirs(out_dir +'/proposal/npys', exist_ok=True)


    names = glob.glob(ensemble_dirs[0] + '/overlays/*/')
    names = [n.split('/')[-2]for n in names]
    sorted(names)

    num_ensemble = len(ensemble_dirs)
    for name in names:
        print(name)
        image_file = ensemble_dirs[0] +'/overlays/%s/%s.png'%(name,name)
        image = cv2.imread(image_file,cv2.IMREAD_COLOR)
        height, width= image.shape[:2]

        image1 = image.copy()
        image2 = image.copy()
        image3 = image.copy()

        detections=[]
        tight_detections=[]
        for t,dir in enumerate(ensemble_dirs):
            npy_file = dir +'/detections/%s.npy'%(name)
            detection = np.load(npy_file)
            tight_detection = make_tight_proposal(detection, 0.25, width, height)

            keep = check_valid(tight_detection, width, height)
            #if lenkeep()==0: continue
            detection       = detection[keep]
            tight_detection = tight_detection[keep]

            detections.append(detection)
            tight_detections.append(tight_detection)
            num_detection = len(detection)
            for n in range(num_detection):
                _,x0,y0,x1,y1,score,label,k = tight_detection[n]  #detection[n]

                color = to_color((score-0.5)/0.5,(0,255,255))
                cv2.rectangle(image2, (x0,y0), (x1,y1), color, 1)

                if t == 0:
                    cv2.rectangle(image1, (x0,y0), (x1,y1), color, 1)

            # image_show('image1',image1,1)
            # cv2.waitKey(0)

        detections = np.vstack(detections)
        tight_detections = np.vstack(tight_detections)
        rois = tight_detections[:,1:6]  #detections[:,1:6]
        keep = cython_nms(rois, 0.5)
        # for i in keep:
        #     #_,x0,y0,x1,y1,score,label,k = detections[i]
        #     x0,y0,x1,y1,score = rois[i]
        #     cv2.rectangle(image3, (x0,y0), (x1,y1), (0,255,0), 1)

        nms = detections[keep]
        tight_nms = tight_detections[keep]

        num_nms = len(nms)
        for i in range(num_nms):
            #_,x0,y0,x1,y1,score,label,k = detections[i]
            x0,y0,x1,y1,score = tight_nms[i][1:6]

            #x0,y0,x1,y1 = small_nms_box[n]
            color = to_color((score-0.5)/0.5,(0,255,255))
            cv2.rectangle(image3, (x0,y0), (x1,y1), color, 1)

            cvs_EncodedPixels.append(image3)
            cvs_ImageId.append(name)


        draw_shadow_text(image1, 'original',  (5,15),0.5, (255,255,255), 1)
        draw_shadow_text(image2, 'all',  (5,15),0.5, (255,255,255), 1)
        draw_shadow_text(image3, 'all(nms)',  (5,15),0.5, (255,255,255), 1)

        all = np.hstack([image1,image3,image2])

        #image_show('image1',image1,1)
        #image_show('image2',image2,1)
        #image_show('image3',image3,1)
        image_show('all',all,1)
        cv2.waitKey(0)

        ##save results ---------------------------------------
        np.save(out_dir +'/proposal/npys/%s.npy'%(name),detections)
        cv2.imwrite(out_dir +'/proposal/overlays/%s.png'%(name),all)

    df = pd.DataFrame({ 'ImageId' : cvs_ImageId , 'EncodedPixels' : cvs_EncodedPixels})
    df.to_csv(csv_file, index=False, columns=['ImageId', 'EncodedPixels'])


def run_ensemble_xxx():

    out_dir = \
        '/home/yl/kaggle_mine/2018_Data_Science_Bowl/Hen/20180306/results/mask-se-resnext50-rcnn_2crop-mega-05c/predict/xx_ensemble1'

    ensemble_dirs = [
        'xx_normal',
        'xx_flip_transpose_1',
        'xx_flip_transpose_2',
        'xx_flip_transpose_3',
        'xx_flip_transpose_4',
        'xx_flip_transpose_5',
        'xx_flip_transpose_6',
        'xx_flip_transpose_7',
        'xx_scale_0.8',
        'xx_scale_1.2',
    ]
    ensemble_dirs = [
        '/home/yl/kaggle_mine/2018_Data_Science_Bowl/Hen/20180306/results/mask-se-resnext50-rcnn_2crop-mega-05c/predict/%s'%e for e in ensemble_dirs
    ]

    #setup ---------------------------------------
    os.makedirs(out_dir +'/proposal/overlays', exist_ok=True)
    os.makedirs(out_dir +'/proposal/npys', exist_ok=True)


    names = glob.glob(ensemble_dirs[0] + '/overlays/*/')
    names = [n.split('/')[-2]for n in names]
    sorted(names)

    num_ensemble = len(ensemble_dirs)
    for name in names:
        print(name)
        image_file = ensemble_dirs[0] +'/overlays/%s.png'%(name)
        image = cv2.imread(image_file,cv2.IMREAD_COLOR)
        height, width= image.shape[:2]

        image1 = image.copy()

        overall = np.zeros((height, width,3),np.float32)

        detections=[]
        tight_detections=[]
        for t,dir in enumerate(ensemble_dirs):
            image_file = dir +'/overlays/%s.png'%(name)
            image = cv2.imread(image_file,cv2.IMREAD_COLOR)
            overall += image


        overall = overall/num_ensemble

        image_show('overall',overall,1)
        #image_show('image2',image2,1)
        #image_show('image3',image3,1)
        #image_show('all',all,1)
        cv2.waitKey(0)
        ##save results ---------------------------------------

        # np.save(out_dir +'/proposal/npys/%s.npy'%(overall),detections)
        # cv2.imwrite(out_dir +'/proposal/overlays/%s.png'%(overall),all)

## post process #######################################################################################
def filter_small(multi_mask, threshold):
    num_masks = int(multi_mask.max())

    j=0
    for i in range(num_masks):
        thresh = (multi_mask==(i+1))

        area = thresh.sum()
        if area < threshold:
            multi_mask[thresh]=0
        else:
            multi_mask[thresh]=(j+1)
            j = j+1

    return multi_mask
# draw  ----------------------------------------------------------------
# def multi_mask_to_overlay_0(multi_mask):
#     overlay = skimage.color.label2rgb(multi_mask, bg_label=0, bg_color=(0, 0, 0))*255
#     overlay = overlay.astype(np.uint8)
#     return overlay

def multi_mask_to_color_overlay(multi_mask, image=None, color=None):

    height,width = multi_mask.shape[:2]
    overlay = np.zeros((height,width,3),np.uint8) if image is None else image.copy()
    num_masks = int(multi_mask.max())
    if num_masks==0: return overlay

    if type(color) in [str] or color is None:
        #https://matplotlib.org/xkcd/examples/color/colormaps_reference.html

        if color is None: color='summer'  #'cool' #'brg'
        color = plt.get_cmap(color)(np.arange(0,1,1/num_masks))
        color = np.array(color[:,:3])*255
        color = np.fliplr(color)
        #np.random.shuffle(color)

    elif type(color) in [list,tuple]:
        color = [ color for i in range(num_masks) ]

    for i in range(num_masks):
        mask = multi_mask==i+1
        overlay[mask]=color[i]
        #overlay = instance[:,:,np.newaxis]*np.array( color[i] ) +  (1-instance[:,:,np.newaxis])*overlay

    return overlay



def multi_mask_to_contour_overlay(multi_mask, image=None, color=[255,255,255]):

    height,width = multi_mask.shape[:2]
    overlay = np.zeros((height,width,3),np.uint8) if image is None else image.copy()
    num_masks = int(multi_mask.max())
    if num_masks==0: return overlay

    for i in range(num_masks):
        mask = multi_mask==i+1
        contour = mask_to_inner_contour(mask)
        overlay[contour]=color

    return overlay

# modifier  ----------------------------------------------------------------

def mask_to_outer_contour(mask):
    pad = np.lib.pad(mask, ((1, 1), (1, 1)), 'reflect')
    contour = (~mask) & (
            (pad[1:-1,1:-1] != pad[:-2,1:-1]) \
          | (pad[1:-1,1:-1] != pad[2:,1:-1])  \
          | (pad[1:-1,1:-1] != pad[1:-1,:-2]) \
          | (pad[1:-1,1:-1] != pad[1:-1,2:])
    )
    return contour

def mask_to_inner_contour(mask):
    pad = np.lib.pad(mask, ((1, 1), (1, 1)), 'reflect')
    contour = mask & (
            (pad[1:-1,1:-1] != pad[:-2,1:-1]) \
          | (pad[1:-1,1:-1] != pad[2:,1:-1])  \
          | (pad[1:-1,1:-1] != pad[1:-1,:-2]) \
          | (pad[1:-1,1:-1] != pad[1:-1,2:])
    )
    return contour

def run_length_encode(x):
    bs = np.where(x.T.flatten())[0]

    rle = []
    prev = -2
    for b in bs:
        if (b>prev+1): rle.extend((b + 1, 0))
        rle[-1] += 1
        prev = b

    #https://www.kaggle.com/c/data-science-bowl-2018/discussion/48561#
    if len(rle)!=0 and rle[-1]+rle[-2] == x.size:
        rle[-2] = rle[-2] -1  #print('xxx')

    rle = ' '.join([str(r) for r in rle])
    return rle

def run_npy_to_sumbit_csv():

    image_dir = '/home/yl/kaggle_mine/2018_Data_Science_Bowl/Hen/20180306/data/image/stage1_test/images'

    submit_dir = \
        '/home/yl/kaggle_mine/2018_Data_Science_Bowl/Hen/20180306/results/mask-se-resnext50-rcnn_2crop-mega-05c/predict/xx_ensemble/proposal'

    # image_dir   = '/root/share/project/kaggle/science2018/data/image/stage1_test/images'
    #
    # submit_dir  = \
    #     '/root/share/project/kaggle/science2018/results/mask-rcnn-50-gray500-02/submit'


    npy_dir = submit_dir  + '/npys'
    csv_file = submit_dir + '/submission-gray53-49000.csv'

    ## start -----------------------------
    all_num=0
    cvs_ImageId = [];
    cvs_EncodedPixels = [];

    npy_files = glob.glob(npy_dir + '/*.npy')
    for npy_file in npy_files:
        name = npy_file.split('/')[-1].replace('.npy','')

        multi_mask = np.load(npy_file)
        multi_mask = multi_mask
        #<todo> ---------------------------------
        #post process here
        multi_mask = filter_small(multi_mask, 8)
        #<todo> ---------------------------------
        num = int( multi_mask.max())
        for m in range(num):
            rle = run_length_encode(multi_mask==m+1)
            cvs_ImageId.append(name)
            cvs_EncodedPixels.append(rle)
        # all_num += num

        #<debug> ------------------------------------
        # print(all_num, num)  ##GT is 4152?
        # image_file = image_dir +'/%s.png'%name
        # image = cv2.imread(image_file)
        # color_overlay   = multi_mask_to_color_overlay(multi_mask)
        # color1_overlay  = multi_mask_to_contour_overlay(multi_mask, color_overlay)
        # contour_overlay = multi_mask_to_contour_overlay(multi_mask, image, [0,8,0])
        # all = np.hstack((image, contour_overlay, color1_overlay)).astype(np.uint8)
        # image_show('all',all)
        # cv2.waitKey(1)


    #exit(0)
    # submission csv  ----------------------------

    #kaggle submission requires all test image to be listed!
    for t in ALL_TEST_IMAGE_ID:
        cvs_ImageId.append(t)
        cvs_EncodedPixels.append('') #null


    df = pd.DataFrame({ 'ImageId' : cvs_ImageId , 'EncodedPixels' : cvs_EncodedPixels})
    df.to_csv(csv_file, index=False, columns=['ImageId', 'EncodedPixels'])
# main #################################################################
if __name__ == '__main__':
    print( '%s: calling main function ... ' % os.path.basename(__file__))
    run_npy_to_sumbit_csv()
    # run_ensemble_box()
    # run_ensemble_xxx()
    print('\nsucess!')