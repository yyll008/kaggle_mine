import pandas as pd

ALL_TEST_IMAGE_ID=pd.read_csv('/home/yl/kaggle_mine/2018_Data_Science_Bowl/Hen/mask-rcnn-ver-12/stage2_ids.csv')