import os, sys
sys.path.append(os.path.dirname(__file__))

#--------------------------------------------------------------

from train_mask_rcnn_net_3 import * #se_resnext50_mask_rcnn_2crop
#from train_mask_rcnn_net_2 import * #se_resnext101_mask_rcnn


#--------------------------------------------------------------
from predict_argumentation import *

ALL_TEST_IMAGE_ID =[
'f0d0ab13ff53adc3c4d57e95a5f83d80b06f2cbc0bf002b52cf7b496612e0ce4',
 'dab46d798d29aff2e99c23f47ed3064f5cafb1644629b015c95a2dd2ee593bb4',
 '4be73d68f433869188fe5e7f09c7f681ed51003da6aa5d19ce368726d8e271ee',
 '31f1fbe85b8899258ea5bcf5f93f7ac8238660c386aeab40649c715bd2e38a0a',
 '912a679e4b9b1d1a75170254fd675b8c24b664d80ad7ea7e460241a23535a406',
 'ade080c6618cbbb0a25680cf847f312b5e19b22bfe1cafec0436987ebe5b1e7e',
 '1cdbfee1951356e7b0a215073828695fe1ead5f8b1add119b6645d2fdc8d844e',
 '519dc0d672d1c295fc69b629af8721ccb1a1f136d1976685a68487e62547ffe0',
 'df40099c6306ca1f47fcc8a62e2fa39486d4e223177afdc51b2ad189691802d8',
 'e17b7aedd251a016c01ef9158e6e4aa940d9f1b35942d86028dc1222192a9258',
 '697a05c6fe4a07c601d46da80885645ad574ea19b47ee795ccff216c9f1f1808',
 'd616d323a9eeb9da1b66f8d5df671d63c092c9919cb2c0b223e29c63257c944d',
 '7f4cbe0b36b5d09466476a7d4e01f4f976c67872d549f4ff47b3e1e3a2b403af',
 'fe9adb627a6f45747c5a8223b671774791ededf9364f6544be487c540107fa4f',
 '505bc0a3928d8aef5ce441c5a611fdd32e1e8eccdc15cc3a52b88030acb50f81',
 '0e132f71c8b4875c3c2dd7a22997468a3e842b46aa9bd47cf7b0e8b7d63f0925',
 '4f949bd8d914bbfa06f40d6a0e2b5b75c38bf53dbcbafc48c97f105bee4f8fac',
 '0114f484a16c152baa2d82fdd43740880a762c93f436c8988ac461c5c9dbe7d5',
 'a4816cc1fb76cb3c5e481186833fc0ae9cf426a1406a2607e974e65e9cddba4f',
 '8922a6ac8fd0258ec27738ca101867169b20d90a60fc84f93df77acd5bf7c80b',
 '336d3e4105766f8ad328a7ee9571e743f376f8cbcf6a969ca7e353fe3235c523',
 'ca20076870e8fb604e61802605a9ac45419c82dd3e23404c56c4869f9502a5ef',
 '699f2992cd71e2e28cf45f81347ff22e76b37541ce88087742884cd0e9aadc68',
 '53df5150ee56253fe5bc91a9230d377bb21f1300f443ba45a758bcb01a15c0e4',
 '78a981bd27ba0c65a9169548665a17bda9f49050d0d3893a6567d1eb92cd003d',
 '191b2b2205f2f5cc9da04702c5d422bc249faf8bca1107af792da63cccfba829',
 '648c8ffa496e1716017906d0bf135debfc93386ae86aa3d4adbda9a505985fd9',
 '1879f4f4f05e2bada0ffeb46c128b8df7a79b14c84f38c3e216a69653495153b',
 '7bdb668e6127b7eafc837a883f0648002bd063c736f55a4f673e787250a3fb04',
 '43a71aeb641faa18742cb826772a8566c6c947d7050f9ab15459de6cc2b3b6af',
 '295682d9eb5acb5c1976a460c085734bfaf38482b0a3f02591c2bfdcd4128549',
 '550450e4bff4036fd671decdc5d42fec23578198d6a2fd79179c4368b9d6da18',
 'eea70a7948d25a9a791dbcb39228af4ea4049fe5ebdee9c04884be8cca3da835',
 '1ef68e93964c2d9230100c1347c328f6385a7bc027879dc3d4c055e6fe80cb3c',
 'ab298b962a63e4be9582513aaa84a5e270adba5fd2b16a50e59540524f63c3b8',
 'fac507fa4d1649e8b24c195d990f1fc3ca3633d917839e1751a9d412a14ab5e3',
 '8b59819fbc92eefe45b1db95c0cc3a467ddcfc755684c7f2ba2f6ccb9ad740ab',
 '9ab2d381f90b485a68b82bc07f94397a0373e3215ad20935a958738e55f3cfc2',
 '0ed3555a4bd48046d3b63d8baf03a5aa97e523aa483aaa07459e7afa39fb96c6',
 'a984e7fb886aa02e29d112766d3ce26a4f78eac540ce7bbdbd42af2761928f6d',
 '1962d0c5faf3e85cda80e0578e0cb7aca50826d781620e5c1c4cc586bc69f81a',
 '432f367a4c5b5674de2e2977744d10289a064e5704b21af6607b4975be47c580',
 'd6eb7ce7723e2f6dc13b90b41a29ded27dbd815bad633fdf582447c686018896',
 'bdc789019cee8ddfae20d5f769299993b4b330b2d38d1218646cf89e77fbbd4d',
 '1747f62148a919c8feb6d607faeebdf504b5e2ad42b6b1710b1189c37ebcdb2c',
 '4727d94c6a57ed484270fdd8bbc6e3d5f2f15d5476794a4e37a40f2309a091e2',
 '52b267e20519174e3ce1e1994b5d677804b16bc670aa5f6ffb6344a0fdf63fde',
 '0a849e0eb15faa8a6d7329c3dd66aabe9a294cccb52ed30a90c8ca99092ae732',
 'd8d4bf68a76e4e4c5f21de7ac613451f7115a04db686151e78b8ec0b6a22022b',
 '38f5cfb55fc8b048e82a5c895b25fefae7a70c71ab9990c535d1030637bf6a1f',
 '5cee644e5ffbef1ba021c7f389b33bafd3b1841f04d3edd7922d5084c2c4e0c7',
 '51c70bb8a299943b27f8b354571272692d8f2705036a1a9562156c76da5f025b',
 '0999dab07b11bc85fb8464fc36c947fbd8b5d6ec49817361cb780659ca805eac'
]


def run_predict():

    out_dir = RESULTS_DIR + '/mask-se-resnext50-rcnn_2crop-mega-05c'
    initial_checkpoint = \
       RESULTS_DIR + '/mask-se-resnext50-rcnn_2crop-mega-05c/checkpoint/00049000_model.pth'

    # augment -----------------------------------------------------------------------------------------------------
    augments=[
        ('normal2',           do_test_augment_identity,       undo_test_augment_identity,       {         } ),
        # ('flip_transpose_1', do_test_augment_flip_transpose, undo_test_augment_flip_transpose, {'type':1,} ),
        # ('flip_transpose_2', do_test_augment_flip_transpose, undo_test_augment_flip_transpose, {'type':2,} ),
        # ('flip_transpose_3', do_test_augment_flip_transpose, undo_test_augment_flip_transpose, {'type':3,} ),
        # ('flip_transpose_4', do_test_augment_flip_transpose, undo_test_augment_flip_transpose, {'type':4,} ),
        # ('flip_transpose_5', do_test_augment_flip_transpose, undo_test_augment_flip_transpose, {'type':5,} ),
        # ('flip_transpose_6', do_test_augment_flip_transpose, undo_test_augment_flip_transpose, {'type':6,} ),
        # ('flip_transpose_7', do_test_augment_flip_transpose, undo_test_augment_flip_transpose, {'type':7,} ),
        # ('scale_0.8',        do_test_augment_scale,  undo_test_augment_scale,     { 'scale_x': 0.8, 'scale_y': 0.8  } ),
        # ('scale_1.1',        do_test_augment_scale,  undo_test_augment_scale,     { 'scale_x': 1.1, 'scale_y': 1.1  } ),
        # ('scale_0.5',        do_test_augment_scale,  undo_test_augment_scale,     { 'scale_x': 0.5, 'scale_y': 0.5  } ),
        # ('scale_1.2',        do_test_augment_scale,  undo_test_augment_scale,     { 'scale_x': 1.2, 'scale_y': 1.2  } ),
    ]

    #----------------------------------------------------------------------------------------


    split = 'test1_ids_gray2_53'  #'BBBC006'   #'valid1_ids_gray2_43'


    #start experiments here! ###########################################################

    os.makedirs(out_dir +'/backup', exist_ok=True)
    backup_project_as_zip(PROJECT_PATH, out_dir +'/backup/code.%s.zip'%IDENTIFIER)

    log = Logger()
    log.open(out_dir+'/log.evaluate.txt',mode='a')
    log.write('\n--- [START %s] %s\n\n' % (IDENTIFIER, '-' * 64))
    log.write('** some experiment setting **\n')
    log.write('\tSEED         = %u\n' % SEED)
    log.write('\tPROJECT_PATH = %s\n' % PROJECT_PATH)
    log.write('\tout_dir      = %s\n' % out_dir)
    log.write('\n')


    ## net ------------------------------
    cfg = Configuration()
    cfg.rcnn_test_nms_pre_score_threshold = 0.5
    cfg.mask_test_nms_pre_score_threshold = cfg.rcnn_test_nms_pre_score_threshold

    net = Net(cfg).cuda()
    if initial_checkpoint is not None:
        log.write('\tinitial_checkpoint = %s\n' % initial_checkpoint)
        net.load_state_dict(torch.load(initial_checkpoint, map_location=lambda storage, loc: storage))

    log.write('%s\n\n'%(type(net)))
    log.write('\n')



    ## dataset ----------------------------------------
    log.write('** dataset setting **\n')

    # ids = read_list_from_file(DATA_DIR + '/split/' + split, comment='#')[:10]
    ids = read_list_from_file(DATA_DIR + '/split/' + split, comment='#')
    log.write('\ttsplit   = %s\n'%(split))
    log.write('\tlen(ids) = %d\n'%(len(ids)))
    log.write('\n')


    for tag_name, do_test_augment, undo_test_augment, params in augments:

        ## setup  --------------------------
        tag = 'xx_%s'%tag_name   ##tag = 'test1_ids_gray2_53-00011000_model'
        os.makedirs(out_dir +'/predict/%s/overlays'%tag, exist_ok=True)
        os.makedirs(out_dir +'/predict/%s/predicts'%tag, exist_ok=True)

        os.makedirs(out_dir +'/predict/%s/rcnn_proposals'%tag, exist_ok=True)
        os.makedirs(out_dir +'/predict/%s/detections'%tag, exist_ok=True)
        os.makedirs(out_dir +'/predict/%s/masks'%tag, exist_ok=True)
        os.makedirs(out_dir +'/predict/%s/instances'%tag, exist_ok=True)



        log.write('** start evaluation here @%s! **\n'%tag)
        for i in range(len(ids)):
            folder, name = ids[i].split('/')[-2:]
            print('%03d %s'%(i,name))

            #'4727d94c6a57ed484270fdd8bbc6e3d5f2f15d5476794a4e37a40f2309a091e2'
            #name='0ed3555a4bd48046d3b63d8baf03a5aa97e523aa483aaa07459e7afa39fb96c6'
            #name='0999dab07b11bc85fb8464fc36c947fbd8b5d6ec49817361cb780659ca805eac'
            image = cv2.imread(DATA_DIR + '/image/%s/images/%s.png'%(folder,name), cv2.IMREAD_COLOR)


            ###--------------------------------------
            augment_image  = do_test_augment(image, proposal=None,  **params)

            #augment_image = cv2.blur(augment_image,(15,15))
            #augment_image = do_unsharp(augment_image)
            #augment_image = do_gamma(augment_image,gamma=0.5)
            #augment_image = do_clahe(augment_image, clip=2, grid=16)

            net.set_mode('test')
            with torch.no_grad():
                input = torch.from_numpy(augment_image.transpose((2,0,1))).float().div(255).unsqueeze(0)
                input = Variable(input).cuda()
                net.forward(input)

            rcnn_proposal, detection, mask, instance  = undo_test_augment(net, image, **params)



            ##save results ---------------------------------------
            np.save(out_dir +'/predict/%s/rcnn_proposals/%s.npy'%(tag,name),rcnn_proposal)
            np.save(out_dir +'/predict/%s/masks/%s.npy'%(tag,name),mask)
            np.save(out_dir +'/predict/%s/detections/%s.npy'%(tag,name),detection)
            np.save(out_dir +'/predict/%s/instances/%s.npy'%(tag,name),instance)

            #----
            if 1:
                norm_image = do_gamma(image,2.5)

                threshold = 0.8  #cfg.rcnn_test_nms_pre_score_threshold  #0.8
                #all1 = draw_predict_proposal(threshold, image, rcnn_proposal)
                all2 = draw_predict_mask(threshold, image, mask, detection)

                ## save
                #cv2.imwrite(out_dir +'/predict/%s/predicts/%s.png'%(tag,name), all1)
                cv2.imwrite(out_dir +'/predict/%s/predicts/%s.png'%(tag,name), all2)

                #image_show('predict_proposal',all1)
                image_show('predict_mask',all2)

                if 1:
                    norm_image      = do_gamma(image,2.5)
                    color_overlay   = mask_to_color_overlay(mask)
                    color1_overlay  = mask_to_contour_overlay(mask, color_overlay)
                    contour_overlay = mask_to_contour_overlay(mask, norm_image, [0,255,0])

                    mask_score = instance.sum(0)
                    #mask_score = cv2.cvtColor((np.clip(mask_score,0,1)*255).astype(np.uint8),cv2.COLOR_GRAY2BGR)
                    mask_score = cv2.cvtColor((mask_score/mask_score.max()*255).astype(np.uint8),cv2.COLOR_GRAY2BGR)

                    all = np.hstack((image, contour_overlay, color1_overlay, mask_score)).astype(np.uint8)
                    image_show('overlays',all)

                    #psd
                    os.makedirs(out_dir +'/predict/overlays', exist_ok=True)
                    cv2.imwrite(out_dir +'/predict/%s/overlays/%s.png'%(tag,name),all)

                    os.makedirs(out_dir +'/predict/%s/overlays/%s'%(tag,name), exist_ok=True)
                    cv2.imwrite(out_dir +'/predict/%s/overlays/%s/%s.png'%(tag,name,name),image)
                    cv2.imwrite(out_dir +'/predict/%s/overlays/%s/%s.mask.png'%(tag,name,name),color_overlay)
                    cv2.imwrite(out_dir +'/predict/%s/overlays/%s/%s.contour.png'%(tag,name,name),contour_overlay)

                cv2.waitKey(1)


        #assert(test_num == len(test_loader.sampler))
        log.write('-------------\n')
        log.write('initial_checkpoint  = %s\n'%(initial_checkpoint))
        log.write('tag=%s\n'%tag)
        log.write('\n')

## post process #######################################################################################
def filter_small(multi_mask, threshold):
    num_masks = int(multi_mask.max())

    j=0
    for i in range(num_masks):
        thresh = (multi_mask==(i+1))

        area = thresh.sum()
        if area < threshold:
            multi_mask[thresh]=0
        else:
            multi_mask[thresh]=(j+1)
            j = j+1

    return multi_mask
def run_npy_to_sumbit_csv():

    image_dir = '/home/yl/kaggle_mine/2018_Data_Science_Bowl/Hen/20180306/data/image/stage1_test/images'

    submit_dir = \
        '/home/yl/kaggle_mine/2018_Data_Science_Bowl/Hen/20180306/results/mask-se-resnext50-rcnn_2crop-mega-05c/predict/xx_normal/'

    # image_dir   = '/root/share/project/kaggle/science2018/data/image/stage1_test/images'
    #
    # submit_dir  = \
    #     '/root/share/project/kaggle/science2018/results/mask-rcnn-50-gray500-02/submit'


    npy_dir = submit_dir  + '/detections'
    csv_file = submit_dir + '/submission-gray53-49000.csv'

    ## start -----------------------------
    all_num=0
    cvs_ImageId = [];
    cvs_EncodedPixels = [];

    npy_files = glob.glob(npy_dir + '/*.npy')
    for npy_file in npy_files:
        name = npy_file.split('/')[-1].replace('.npy','')

        multi_mask = np.load(npy_file)

        #<todo> ---------------------------------
        #post process here
        multi_mask = filter_small(multi_mask, 8)
        #<todo> ---------------------------------

        num = int( multi_mask.max())
        for m in range(num):
            rle = run_length_encode(multi_mask==m+1)
            cvs_ImageId.append(name)
            cvs_EncodedPixels.append(rle)
        all_num += num

        #<debug> ------------------------------------
        print(all_num, num)  ##GT is 4152?
        image_file = image_dir +'/%s.png'%name
        image = cv2.imread(image_file)
        norm_image = do_gamma(image, 2.5)
        mask = multi_mask
        color_overlay = mask_to_color_overlay(mask)
        color1_overlay = mask_to_contour_overlay(mask, color_overlay)
        contour_overlay = mask_to_contour_overlay(mask, norm_image, [0, 255, 0])

        # color_overlay   = multi_mask_to_color_overlay(multi_mask)
        # color1_overlay  = multi_mask_to_contour_overlay(multi_mask, color_overlay)
        # contour_overlay = multi_mask_to_contour_overlay(multi_mask, image, [0,255,0])
        all = np.hstack((image, contour_overlay, color1_overlay)).astype(np.uint8)
        image_show('all',all)
        cv2.waitKey(1)


    #exit(0)
    # submission csv  ----------------------------

    # kaggle submission requires all test image to be listed!
    for t in ALL_TEST_IMAGE_ID:
        cvs_ImageId.append(t)
        cvs_EncodedPixels.append('') #null


    df = pd.DataFrame({ 'ImageId' : cvs_ImageId , 'EncodedPixels' : cvs_EncodedPixels})
    df.to_csv(csv_file, index=False, columns=['ImageId', 'EncodedPixels'])

# main #################################################################
if __name__ == '__main__':
    print( '%s: calling main function ... ' % os.path.basename(__file__))

    # run_predict()
    run_npy_to_sumbit_csv()
    print('\nsucess!')